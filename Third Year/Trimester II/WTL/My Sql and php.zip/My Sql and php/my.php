<?php

echo "<h1>string</h1>";
print("<br><hr>Hello");

$in=-8;
$fl=9.9;
$str="YASH";
#NO DEFINITION OF VARIABLES
/*
Multiline Comments
*/
echo "<br>$in, $fl, $str";

if ($in>0)
{
	print("<br>INTEGER");
}
elseif ($in<0)
{
	print("<br>Negative");
}
else
{
	print("<br>UNDEFINED");
}
print("<hr>");
echo "<br>ODD:";
for ($i=0; $i <10 ; $i++)
{
	
	if ($i%2!=0)
	{
		print("$i\n");
	}
}
print("<hr>");
echo "<br>EVEN:";
$j=0;
while ($j<= 10) 
{
	if ($j%2==0)
	{
		print("$j\n");
	}
	$j++;
}
print("<hr><br>");
$k=0;
do 
{
	print("$k\n");
	$k++;
} while ( $k<= 10);

print("<hr>");
echo "<br>Prime:";
for ($i=1; $i <50 ; $i++)
{
	$flag=0;
	for ($j=2; $j<$i; $j++) 
	{
		if ($i % $j  == 0) 
        {
            $flag = 1; 
            break; 
        }
    }
    if($flag==0)
    {
    	print("$i\n");
    }
}

print("<hr>");
echo "<br>Switch:";
$l=1;
switch ($l) 
{
	case '1':
		print("Case 1\n");
		$l++;
		break;
	case '2':
		print("Case 2\n");
		$l++;
		break;
	default:
		print("default case\n");
		break;
}
print("<hr>");
/*
echo "<br>Image:";
$s="C:\Users\student\Desktop\123.jpg"
echo "<img src=$s>";
*/
?>