<?php
$name=$_POST['Name'];
$id=$_POST['Rollno'];

$host='localhost';
$user='root';
$pass='';
$db='db_y';


$connection=mysqli_connect($host,$user,$pass,$db);

if (!$connection) {
	print("connection not successful");
}
else
{
	print("Connected");
}

echo "<br><br>";
/*
//Create Table
$create="create table data (Name varchar(30), Id int(2))";
mysqli_query($connection,$create);
*/

//Insert Data
$query="INSERT INTO data (Name, Id) VALUES ('".$name."', '".$id."')";
if (mysqli_query($connection,$query)) {
	print("Inserted successful");
	
}
else
{
	print("Insertion Not Successful");
}

/*
Remove Data

$query1="DELETE FROM data WHERE Id='20'";
*/

?>
